export type CellsNetworkDTO = {
  id?: string
  name: string
  supervisorId: string
  color: string
  image?: string | null
} 