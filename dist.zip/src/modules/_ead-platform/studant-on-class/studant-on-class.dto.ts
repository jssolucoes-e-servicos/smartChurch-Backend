export type StudantOnClassDTO = {
  id?: string;
  studantId: string;
  courseClassId: string;
  active: boolean;
};
