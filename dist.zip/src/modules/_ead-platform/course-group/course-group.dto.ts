export type CourseGroupDTO = {
  id?: string;
  name: string;
  churchId: string;
};
