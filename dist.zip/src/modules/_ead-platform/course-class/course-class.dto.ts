export type CourseClassDTO = {
  id?: string;
  name: string;
  active: boolean;
  courseId: string;
};
